Put image assets here:
- /content/services  -> for jasa (service) galleries
- /content/products  -> for product galleries

Use .webp images and keep filenames consistent with the JSON in src/data.
